using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.IO.Compression;
using UnityEngine.Android;

public class CoreScript : MonoBehaviour
{
    string[] strs = new string[] {
        "android.permission.INTERNET",
        "android.permission.READ_PHONE_STATE",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.ACCESS_WIFI_STATE",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.GET_TASKS",
        "android.permission.REQUEST_INSTALL_PACKAGES",
        "android.permission.WAKE_LOCK",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.CHANGE_WIFI_STATE",
        "android.permission.CHANGE_NETWORK_STATE",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.SYSTEM_OVERLAY_WINDOW",
        "android.permission.ACCESS_COARSE_UPDATES",
        "android.permission.WRITE_SETTINGS",
        "android.permission.BATTERY_STATS",
        "android.permission.MOUNT_UNMOUNT_FILESYSTEMS"
    };
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i <= strs.Length - 1; i++)
        {
            Permission.RequestUserPermission(strs[i]);
            Debug.Log("����Ȩ��: " + strs[i]);
        }
        Permission.RequestUserPermission(Permission.Camera);
        Permission.RequestUserPermission(Permission.Microphone);
        Permission.RequestUserPermission(Permission.FineLocation);
        Permission.RequestUserPermission(Permission.CoarseLocation);
        Permission.RequestUserPermission(Permission.ExternalStorageRead);
        Permission.RequestUserPermission(Permission.ExternalStorageWrite);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public static void DownloadFile(string url, string path)
    {
        using (System.Net.WebClient client = new System.Net.WebClient())
        {
            client.DownloadFile(url, path + "/FogMoe-Temp-YGO.zip");
        }
    }
    public static void DeleteFile(string path)
    {
        System.IO.File.Delete(path);
    }

    public static void Unzip(string path)
    {
        using (ZipArchive archive = ZipFile.OpenRead(path + "/FogMoe-Temp-YGO.zip"))
        {
            ZipFile.ExtractToDirectory(path + "/FogMoe-Temp-YGO.zip", path);
        }
    }
    public static void CopyFilesRecursively(string sourcePath, string targetPath)
    {
        foreach (string dirPath in Directory.GetDirectories(sourcePath, "*", SearchOption.AllDirectories))
        {
            Directory.CreateDirectory(dirPath.Replace(sourcePath, targetPath));
        }
        foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
        {
            File.Copy(newPath, newPath.Replace(sourcePath, targetPath), true);
        }
        Directory.Delete(sourcePath, true);
    }    
}
