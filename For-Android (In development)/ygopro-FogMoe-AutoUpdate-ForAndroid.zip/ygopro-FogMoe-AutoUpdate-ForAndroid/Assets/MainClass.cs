using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainClass : MonoBehaviour
{
    string nodeUrl = "https://ygodiydata.github.fogmoe.top/";
    string gameFolderPath = "/storage/emulated/0/Android/data/cn.garymb.ygomobile/files/ygocore";
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClick()
    {
        CoreScript.DownloadFile(nodeUrl, gameFolderPath);
        CoreScript.Unzip(gameFolderPath);
        CoreScript.DeleteFile(gameFolderPath + "/FogMoe-Temp-YGO.zip");
        CoreScript.CopyFilesRecursively(gameFolderPath + "/ygopro-FogMoe-card-database-main", gameFolderPath + "/expansions");
        GameObject.Find("Text1").GetComponent<Text>().text = "���º��ˣ�";
    }
}
